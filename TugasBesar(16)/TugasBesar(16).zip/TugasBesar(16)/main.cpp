#include <iostream>
#include "tubes.h"
using namespace std;

int main()
{
    ListBuku LB;
    ListPenulis LP;
    ListRelasi LR;
    int pilihan;


    createlistBuku(LB);
    createElmPenulis(LP);






    createElmBuku()
    pilihan = menuUtama();
    while (pilihan != 0) {
        if (pilihan == 1){
           menuBuku();

        }else if (pilihan == 2){
            menuPenulis()
        }else{
            cout<< "tekan x untuk kembali" << endl;

        }
    }

}



    cout << "ANDA TELAH KELUAR DARI PROGRAM";

}


}
